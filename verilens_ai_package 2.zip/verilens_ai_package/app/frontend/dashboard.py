"""
VeriLens AI — Streamlit Dashboard
Run: streamlit run app/frontend/dashboard.py
"""
import streamlit as st
import sys, os, json, joblib, numpy as np
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

# ── Page config ───────────────────────────────────────────────
st.set_page_config(
    page_title="VeriLens AI",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ── Load models (cached) ─────────────────────────────────────
@st.cache_resource
def load_models():
    from verilens_inference import (xgb, scaler, SPEAKER_MEMORY, FEAT_COLS,
        LING_COLS, explainer, VTI_WEIGHTS, compute_vti, extract_text_from_image,
        display_speaker_profile)
    return xgb, scaler, SPEAKER_MEMORY, FEAT_COLS, LING_COLS, explainer, VTI_WEIGHTS, compute_vti, extract_text_from_image, display_speaker_profile

xgb, scaler, SPEAKER_MEMORY, FEAT_COLS, LING_COLS, explainer, VTI_WEIGHTS, compute_vti, ocr_fn, spk_fn = load_models()

# ── Header ───────────────────────────────────────────────────
st.title("🔍 VeriLens AI — Fake News Detection")
st.markdown("*DistilBERT + XGBoost + SHAP | VeriLens Trust Index v2.0*")
st.divider()

# ── Sidebar ──────────────────────────────────────────────────
with st.sidebar:
    st.header("⚙️ Settings")
    speaker = st.text_input("Speaker / Author", value="unknown",
                            help="Enter speaker name for credibility lookup")
    st.divider()
    st.markdown("**VTI Component Weights**")
    for k, w in VTI_WEIGHTS.items():
        st.write(f"  {k}: **{w*100:.0f}%**")
    st.divider()
    if speaker.strip().lower() not in ('unknown', ''):
        st.subheader("👤 Speaker Profile")
        prof = spk_fn(speaker)
        if isinstance(prof, dict):
            for pk, pv in prof.items():
                st.write(f"**{pk}:** {pv}")
        else:
            st.info(prof)

# ── Input tabs ───────────────────────────────────────────────
tab1, tab2 = st.tabs(["📝 Text Input", "📷 Image / Screenshot"])

with tab1:
    text_input = st.text_area("Paste article or claim text here",
                               height=200, placeholder="Enter news article or claim...")
    col1, col2 = st.columns([1, 4])
    with col1:
        run_text = st.button("🔍 Analyse", type="primary", use_container_width=True)
    result_text = None
    if run_text and text_input.strip():
        with st.spinner("Analysing..."):
            result_text = compute_vti(text_input, speaker=speaker)

with tab2:
    uploaded = st.file_uploader("Upload screenshot", type=['png','jpg','jpeg','webp'])
    run_ocr  = st.button("🔍 OCR + Analyse", type="primary")
    result_ocr = None
    if run_ocr and uploaded:
        import tempfile, shutil
        suf = os.path.splitext(uploaded.name)[-1]
        with tempfile.NamedTemporaryFile(delete=False, suffix=suf) as tmp:
            shutil.copyfileobj(uploaded, tmp); tmp_path = tmp.name
        with st.spinner("Running OCR + VTI analysis..."):
            result_ocr = compute_vti("", speaker=speaker, image_path=tmp_path)
        os.unlink(tmp_path)

# ── Display result ────────────────────────────────────────────
result = result_text or result_ocr
if result and 'vti' in result:
    vti = result['vti']
    st.divider()
    st.subheader("📊 Analysis Results")

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("VeriLens Trust Index", f"{vti}/100")
    col2.metric("Verdict", result['verdict'])
    col3.metric("Risk Level", result['risk_level'])
    col4.metric("Recommendation", "Verify ⚠️" if vti < 50 else "Credible ✔️")

    st.divider()

    # VTI Component breakdown
    st.subheader("🏆 VTI Component Breakdown")
    import plotly.graph_objects as go
    comps = result['components']
    fig = go.Figure(go.Bar(
        x=list(comps.values()), y=list(comps.keys()),
        orientation='h', marker_color='#01696f',
        text=[f"{v:.1f}" for v in comps.values()], textposition='outside'
    ))
    fig.update_layout(xaxis=dict(range=[0,100]), height=280,
                      title="Component Scores (0–100, higher = more trustworthy)",
                      margin=dict(l=20,r=20,t=40,b=20))
    st.plotly_chart(fig, use_container_width=True)

    # Explanation
    st.subheader("💡 Explanation")
    for r in result['reasons']:
        st.write(f"  • {r}")
    st.info(result['recommendation'])

    # SHAP
    col_pos, col_neg = st.columns(2)
    with col_pos:
        st.subheader("✅ REAL Indicators (SHAP)")
        for feat, val in result.get('shap_positive', []):
            st.write(f"  **{feat}**: +{val:.4f}")
    with col_neg:
        st.subheader("❌ FAKE Indicators (SHAP)")
        for feat, val in result.get('shap_negative', []):
            st.write(f"  **{feat}**: {val:.4f}")

    # Speaker profile
    if result.get('speaker_profile'):
        st.divider()
        st.subheader("👤 Speaker Profile")
        sp = result['speaker_profile']
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Total Claims", sp.get('claims','—'))
        c2.metric("True %", f"{sp.get('truth_rate',0)*100:.1f}%")
        c3.metric("False %", f"{sp.get('false_rate',0)*100:.1f}%")
        c4.metric("Credibility", f"{sp.get('cred_score',0)*100:.0f}/100")

    with st.expander("🔬 Full Linguistic Flags"):
        st.json(result.get('linguistic_flags', {}))
