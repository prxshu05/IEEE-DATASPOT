"""
VeriLens AI — FastAPI Backend
Run: uvicorn app.backend.api:app --host 0.0.0.0 --port 8000 --reload
"""
import sys, os, json, logging
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import uvicorn

logging.basicConfig(level=logging.INFO, format='%(asctime)s | %(levelname)s | %(message)s')
logger = logging.getLogger('VeriLens-API')

# ── Lazy model loading (avoids slow import on startup) ───────
_models_loaded = False
def _load_models():
    global _models_loaded, xgb, scaler, SPEAKER_MEMORY
    global FEAT_COLS, LING_COLS, explainer, VTI_WEIGHTS, VTI_THRESHOLDS
    global compute_vti, extract_text_from_image
    if not _models_loaded:
        from verilens_inference import (xgb, scaler, SPEAKER_MEMORY, FEAT_COLS,
            LING_COLS, explainer, VTI_WEIGHTS, VTI_THRESHOLDS,
            compute_vti, extract_text_from_image)
        _models_loaded = True
        logger.info("Models loaded")

# ── App ──────────────────────────────────────────────────────
app = FastAPI(
    title       = "VeriLens AI API",
    description = "Explainable Fake News Detection — VeriLens Trust Index",
    version     = "2.0.0"
)
app.add_middleware(CORSMiddleware, allow_origins=["*"],
                   allow_methods=["*"], allow_headers=["*"])

# ── Schemas ──────────────────────────────────────────────────
class PredictRequest(BaseModel):
    text:    str
    speaker: Optional[str] = "unknown"

class PredictResponse(BaseModel):
    vti:            float
    verdict:        str
    risk_level:     str
    components:     dict
    reasons:        list
    recommendation: str
    shap_positive:  list
    shap_negative:  list

# ── Endpoints ─────────────────────────────────────────────────
@app.get("/health")
def health():
    return {"status": "ok", "service": "VeriLens AI", "version": "2.0.0"}

@app.post("/predict", response_model=PredictResponse)
def predict(req: PredictRequest):
    _load_models()
    if not req.text or len(req.text.strip()) < 10:
        raise HTTPException(status_code=400, detail="Text must be at least 10 characters.")
    try:
        result = compute_vti(req.text, speaker=req.speaker or "unknown")
        logger.info(f"Prediction: VTI={result['vti']} | {result['verdict']}")
        return result
    except Exception as e:
        logger.error(f"Prediction error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/ocr")
async def ocr_endpoint(file: UploadFile = File(...), speaker: str = "unknown"):
    _load_models()
    import tempfile, shutil
    suffix = os.path.splitext(file.filename)[-1] or ".jpg"
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        shutil.copyfileobj(file.file, tmp)
        tmp_path = tmp.name
    try:
        text   = extract_text_from_image(tmp_path)
        result = compute_vti(text, speaker=speaker) if text else {"error": "OCR returned no text"}
        return {"extracted_text": text, "analysis": result}
    finally:
        os.unlink(tmp_path)

@app.get("/speaker/{speaker_name}")
def speaker_profile(speaker_name: str):
    _load_models()
    key  = speaker_name.lower().strip()
    data = SPEAKER_MEMORY.get(key)
    if not data:
        raise HTTPException(status_code=404, detail=f"Speaker '{speaker_name}' not in memory.")
    return {"speaker": key, **data}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
