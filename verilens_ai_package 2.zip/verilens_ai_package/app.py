# ============================================================
#  MultiVerify — Streamlit App
#  Run: streamlit run app.py
# ============================================================
import streamlit as st
import pandas as pd
import numpy as np
import re, math, json, joblib, warnings
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import plotly.graph_objects as go
import nltk, torch
warnings.filterwarnings('ignore')

BASE_DIR = Path(__file__).resolve().parent

# ── Page Config ──────────────────────────────────────────────
st.set_page_config(
    page_title="MultiVerify",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ── Custom CSS ───────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://api.fontshare.com/v2/css?f[]=satoshi@400,500,700&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,700;9..144,800&display=swap');
:root {
    --bg: #f4efe8;
    --panel: rgba(255, 255, 255, 0.82);
    --panel-strong: #ffffff;
    --ink: #12333a;
    --muted: #6c6a63;
    --brand: #01696f;
    --brand-deep: #0c4e54;
    --accent: #e07a3f;
    --border: rgba(18, 51, 58, 0.12);
    --shadow: 0 20px 60px rgba(16, 34, 41, 0.10);
}
html, body {
    background:
        radial-gradient(circle at top left, rgba(1, 105, 111, 0.10), transparent 24%),
        radial-gradient(circle at right 18%, rgba(224, 122, 63, 0.12), transparent 20%),
        linear-gradient(180deg, #fbf8f4 0%, #f4efe8 100%);
    color: var(--ink);
}
html, body, [class*="css"] { font-family: 'Satoshi', sans-serif; }
.stApp { background: transparent; }
.block-container {
    padding-top: clamp(1rem, 2vw, 2rem);
    padding-bottom: clamp(1.25rem, 2.5vw, 2.5rem);
    padding-left: clamp(0.75rem, 2vw, 1.5rem);
    padding-right: clamp(0.75rem, 2vw, 1.5rem);
    max-width: min(100vw - 1.5rem, 1240px);
    width: 100%;
}
.big-score { font-size: 4rem; font-weight: 800; text-align: center; line-height: 1; }
.verdict   { font-size: 1.3rem; font-weight: 600; text-align: center; margin-top: 4px; }
.chip {
    display: inline-flex; align-items: center; gap: 6px;
    background: rgba(1, 105, 111, 0.08);
    border: 1px solid rgba(1, 105, 111, 0.14);
    border-radius: 999px; padding: 7px 14px;
    margin: 4px 6px 0 0; font-size: 0.84rem; color: var(--ink);
}
.score-box {
    border-radius: 28px; padding: 28px 22px;
    text-align: center; border: 1px solid rgba(18, 51, 58, 0.10);
    box-shadow: var(--shadow); backdrop-filter: blur(12px);
}
.stButton > button {
    background: linear-gradient(135deg, var(--brand) 0%, #0b7a84 100%);
    color: white; border-radius: 14px;
    font-weight: 700; border: none; padding: 0.8rem 2rem;
    font-size: 1rem; width: 100%; box-shadow: 0 10px 24px rgba(1, 105, 111, 0.24);
}
.stButton > button:hover { background: linear-gradient(135deg, #0c4e54 0%, #09555b 100%); }
.hero {
    background: linear-gradient(135deg, rgba(1, 105, 111, 0.12), rgba(255, 255, 255, 0.70));
    border: 1px solid rgba(1, 105, 111, 0.10);
    border-radius: 32px;
    padding: 28px 28px 24px;
    box-shadow: var(--shadow);
    overflow: hidden;
}
.hero h1 {
    font-family: 'Fraunces', serif;
    font-size: clamp(2.3rem, 3.8vw, 4rem);
    line-height: 0.95;
    margin: 0;
    color: var(--ink);
}
.hero p {
    margin: 0.8rem 0 0;
    color: var(--muted);
    font-size: 1.02rem;
    max-width: 760px;
}
.pill-row {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-top: 18px;
}
.pill {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 8px 14px;
    border-radius: 999px;
    background: rgba(255, 255, 255, 0.80);
    border: 1px solid rgba(18, 51, 58, 0.10);
    color: var(--ink);
    font-size: 0.86rem;
    font-weight: 600;
}
.panel {
    background: var(--panel);
    border: 1px solid var(--border);
    border-radius: 28px;
    padding: 22px;
    box-shadow: var(--shadow);
    backdrop-filter: blur(12px);
    width: 100%;
}
.panel h1,
.panel h2,
.panel h3,
.panel h4,
.panel h5,
.panel h6,
.panel [data-testid="stMarkdownContainer"] h1,
.panel [data-testid="stMarkdownContainer"] h2,
.panel [data-testid="stMarkdownContainer"] h3,
.panel [data-testid="stMarkdownContainer"] h4,
.panel [data-testid="stMarkdownContainer"] h5,
.panel [data-testid="stMarkdownContainer"] h6,
.panel p,
.panel li,
.panel span,
.panel label {
    color: var(--ink) !important;
}
.panel input,
.panel textarea {
    color: var(--ink) !important;
}
.panel input::placeholder,
.panel textarea::placeholder {
    color: rgba(18, 51, 58, 0.48) !important;
    opacity: 1 !important;
}
.panel button[data-testid="stExpanderToggleButton"],
.panel button[data-testid="stExpanderToggleButton"] * {
    color: var(--ink) !important;
    opacity: 1 !important;
}
.examples-box {
    margin: 14px 0 12px;
    padding: 14px 14px 12px;
    border-radius: 18px;
    background: rgba(1, 105, 111, 0.05);
    border: 1px solid rgba(1, 105, 111, 0.14);
}
.examples-title {
    color: var(--ink);
    font-size: 0.96rem;
    font-weight: 900;
    letter-spacing: 0.01em;
    margin-bottom: 10px;
}
.examples-box div[data-testid="stButton"] button {
    background: #ffffff;
    color: var(--ink) !important;
    border: 1px solid rgba(18, 51, 58, 0.12);
    box-shadow: none;
    text-align: left;
    justify-content: flex-start;
}
.examples-box div[data-testid="stButton"] button:hover {
    background: rgba(1, 105, 111, 0.08);
    border-color: rgba(1, 105, 111, 0.20);
}
.panel .metric-label,
.panel .metric-note,
.panel .chip {
    color: var(--muted) !important;
}
.metric-card {
    background: linear-gradient(180deg, rgba(255,255,255,0.94), rgba(244,239,232,0.88));
    border: 1px solid rgba(18, 51, 58, 0.10);
    border-radius: 22px;
    padding: 18px 16px;
    box-shadow: 0 14px 32px rgba(16, 34, 41, 0.06);
}
.metric-card .metric-label,
.metric-card .metric-note,
.metric-card .metric-value {
    color: var(--ink) !important;
}
.metric-label {
    color: var(--muted);
    font-size: 0.84rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.08em;
}
.metric-value {
    color: var(--ink);
    font-size: 1.6rem;
    font-weight: 800;
    margin-top: 6px;
}
.metric-note { color: var(--muted); font-size: 0.86rem; margin-top: 4px; }
div[data-testid="stSidebar"] {
    background: linear-gradient(180deg, rgba(18, 51, 58, 0.97) 0%, rgba(7, 27, 30, 0.98) 100%);
    color: #f6f2ec;
    border-right: 1px solid rgba(255,255,255,0.08);
}
div[data-testid="stSidebar"] [data-testid="stMarkdownContainer"] p,
div[data-testid="stSidebar"] [data-testid="stMarkdownContainer"] span,
div[data-testid="stSidebar"] [data-testid="stMarkdownContainer"] div {
    color: inherit;
}
div[data-testid="stSidebar"] .stSuccess,
div[data-testid="stSidebar"] .stInfo {
    border-radius: 16px;
}

@media (max-width: 1100px) {
    .hero {
        padding: 22px;
    }
    .hero h1 {
        font-size: clamp(2rem, 5.5vw, 3.2rem);
    }
    .hero p {
        font-size: 0.98rem;
    }
    .pill-row {
        gap: 8px;
    }
    .pill {
        width: 100%;
        justify-content: flex-start;
    }
    .panel {
        padding: 18px;
        border-radius: 24px;
    }
    .score-box {
        padding: 22px 18px;
    }
}

@media (max-width: 820px) {
    .block-container {
        max-width: 100vw;
        padding-left: 0.85rem;
        padding-right: 0.85rem;
    }
    .hero {
        border-radius: 22px;
    }
    .hero h1 {
        font-size: clamp(1.7rem, 8.2vw, 2.8rem);
    }
    .hero p {
        line-height: 1.5;
    }
    .panel [data-testid="stTextArea"] textarea,
    .panel [data-testid="stTextInput"] input {
        font-size: 1rem;
    }
    .panel button {
        min-height: 3rem;
    }
    .panel .metric-card {
        padding: 16px 14px;
    }
    .panel .metric-value {
        font-size: 1.35rem;
    }
}

@media (max-width: 640px) {
    .block-container {
        padding-left: 0.6rem;
        padding-right: 0.6rem;
    }
    .hero {
        padding: 18px 16px;
    }
    .hero h1 {
        font-size: 1.8rem;
    }
    .hero p {
        font-size: 0.94rem;
    }
    .pill {
        width: 100%;
        padding: 10px 12px;
    }
    .panel {
        padding: 16px;
        border-radius: 20px;
    }
    .score-box {
        padding: 18px 14px;
        border-radius: 22px;
    }
    .big-score {
        font-size: 3.2rem;
    }
    .verdict {
        font-size: 1.1rem;
    }
    .metric-card {
        padding: 14px 12px;
        border-radius: 18px;
    }
    .examples-box {
        padding: 12px;
    }
    .examples-box div[data-testid="stButton"] button {
        white-space: normal;
        line-height: 1.35;
    }
}
</style>
""", unsafe_allow_html=True)

# ── NLTK ─────────────────────────────────────────────────────
@st.cache_resource(show_spinner=False)
def load_nltk():
    for r in ['punkt','stopwords','averaged_perceptron_tagger','punkt_tab']:
        nltk.download(r, quiet=True)
    from nltk.corpus import stopwords
    return set(stopwords.words('english'))
STOP = load_nltk()

# ── Word Lists ───────────────────────────────────────────────
EMOTIONAL = set(['shocking','outrageous','incredible','unbelievable','horrifying',
    'amazing','terrifying','devastating','explosive','breaking','urgent',
    'exposed','truth','revealed','secret','fraud','corrupt','evil','deadly','danger'])
SENSATIONAL = set(['suppressed','forbidden','whistleblower','insider','leaked',
    'you won\'t believe','the truth about','what they don\'t want','must see',
    'doctors hate','shocking','exposed','viral','jaw-dropping','mind-blowing'])
HEDGING   = set(['may','might','could','possibly','perhaps','allegedly','reportedly',
    'claims','suggests','appears','seems','supposedly','presumably','apparently'])
CERTAINTY = set(['definitely','certainly','absolutely','clearly','obviously',
    'undoubtedly','proven','confirmed','fact','always','never','every','all','none'])
NEG_FRAME = set(['fail','failure','crisis','disaster','attack','threat','violent',
    'criminal','corrupt','illegal','banned','destroyed','collapsed','worst','terrible'])
CLICKBAIT = ["you won't believe","the truth about","what they don't want",
             'shocking','exposed','viral','jaw-dropping','mind-blowing']

LING_COLS = ['word_count','sent_count','avg_sent_len','sent_variance','caps_ratio',
             'excl_density','quest_density','emo_ratio','hedge_ratio','clickbait_score',
             'quote_ratio','num_density','title_caps','url_count','lexical_diversity',
             'first_person','certainty_ratio','neg_framing','title_word_count','proper_sent_start',
             'sensational_ratio','sensational_count','emo_word_count','passive_voice_ratio',
             'uppercase_word_ratio','readability_norm']
FEAT_COLS = LING_COLS + ['cred_score']

# ── Feature Extraction ───────────────────────────────────────
def extract_linguistic_features(text):
    from nltk.tokenize import sent_tokenize, word_tokenize
    try:
        from textstat import textstat
        textstat_available = True
    except Exception:
        textstat_available = False
    text  = str(text)
    words = word_tokenize(text.lower())
    sents = sent_tokenize(text)
    alpha = [w for w in words if w.isalpha()]
    n_w   = max(len(alpha), 1)
    n_s   = max(len(sents), 1)
    slens = [len(word_tokenize(s)) for s in sents]
    passive_ct = len(re.findall(r'\b(was|were|been|is|are|has been|have been|had been)\s+\w+ed\b', text.lower()))
    full_caps_ct = sum(1 for w in words if len(w) > 1 and w.isupper() and w.isalpha())
    if textstat_available and len(text.split()) >= 10:
        raw_flesch = textstat.flesch_reading_ease(text)
        readability_norm = max(0.0, min(1.0, raw_flesch / 100.0))
    else:
        readability_norm = 0.5
    return {
        'word_count':        n_w,
        'sent_count':        n_s,
        'avg_sent_len':      np.mean(slens) if slens else 0,
        'sent_variance':     np.var(slens) if len(slens) > 1 else 0,
        'caps_ratio':        sum(1 for c in text if c.isupper()) / max(len(text),1),
        'excl_density':      text.count('!') / n_s,
        'quest_density':     text.count('?') / n_s,
        'emo_ratio':         sum(1 for w in alpha if w in EMOTIONAL)  / n_w,
        'hedge_ratio':       sum(1 for w in alpha if w in HEDGING)    / n_w,
        'clickbait_score':   sum(1 for cb in CLICKBAIT if cb in text.lower()) / len(CLICKBAIT),
        'quote_ratio':       len(re.findall(r'"[^"]*"', text)) / n_s,
        'num_density':       len(re.findall(r'\b\d+\.?\d*\b', text)) / n_w,
        'title_caps':        sum(1 for w in alpha if w.istitle()) / n_w,
        'url_count':         len(re.findall(r'http\S+|www\.\S+', text)),
        'lexical_diversity': len(set(alpha)) / n_w,
        'first_person':      sum(1 for w in words if w in ['we','our','us']) / n_w,
        'certainty_ratio':   sum(1 for w in alpha if w in CERTAINTY)  / n_w,
        'neg_framing':       sum(1 for w in alpha if w in NEG_FRAME)  / n_w,
        'title_word_count':  len(text.split()[:15]),
        'proper_sent_start': sum(1 for s in sents if s.strip() and s.strip()[0].isupper()) / n_s,
        'sensational_ratio': sum(1 for w in alpha if w in SENSATIONAL) / n_w,
        'sensational_count': float(sum(1 for w in alpha if w in SENSATIONAL)),
        'emo_word_count':    float(sum(1 for w in alpha if w in EMOTIONAL)),
        'passive_voice_ratio': passive_ct / n_s,
        'uppercase_word_ratio': full_caps_ct / n_w,
        'readability_norm':  readability_norm,
    }

# ── Load Models ──────────────────────────────────────────────
@st.cache_resource(show_spinner=True)
def load_models():
    def load_first_existing(*names):
        for name in names:
            path = BASE_DIR / name
            if path.exists():
                return joblib.load(path)
        raise FileNotFoundError(f"None of the model files exist: {', '.join(names)}")

    xgb    = load_first_existing('verilens_xgb_model.joblib', 'multiverify_xgb_model.joblib')
    scaler = load_first_existing('verilens_scaler.joblib', 'multiverify_scaler.joblib')
    with open(BASE_DIR / 'speaker_memory.json') as f:
        spk = json.load(f)
    return xgb, scaler, spk

@st.cache_resource(show_spinner=True)
def load_bert():
    import shap
    from transformers import AutoTokenizer, AutoModel
    DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
    tok    = AutoTokenizer.from_pretrained('distilbert-base-uncased')
    mdl    = AutoModel.from_pretrained('distilbert-base-uncased').to(DEVICE)
    mdl.eval()
    FAKE_P = 'This is false misleading manipulated fabricated unverified fake news'
    REAL_P = 'This is verified accurate factual credible confirmed reliable true information'
    def emb(t):
        enc = tok(t, return_tensors='pt', truncation=True,
                  max_length=128, padding='max_length').to(DEVICE)
        with torch.no_grad():
            out = mdl(**enc)
        return out.last_hidden_state[:,0,:].cpu().numpy().flatten()
    fake_proto = emb(FAKE_P)
    real_proto = emb(REAL_P)
    return tok, mdl, DEVICE, fake_proto, real_proto, shap

xgb_model, scaler, SPEAKER_MEMORY = load_models()
tokenizer, bert_mdl, DEVICE, FAKE_PROTO, REAL_PROTO, shap = load_bert()
explainer = shap.TreeExplainer(xgb_model)

# ── BERT Inference ───────────────────────────────────────────
def bert_fake_probability(text):
    def cosine(a, b):
        return float(np.dot(a,b)/(np.linalg.norm(a)*np.linalg.norm(b)+1e-9))
    enc = tokenizer(text, return_tensors='pt', truncation=True,
                    max_length=128, padding='max_length').to(DEVICE)
    with torch.no_grad():
        out = bert_mdl(**enc)
    e        = out.last_hidden_state[:,0,:].cpu().numpy().flatten()
    sim_fake = cosine(e, FAKE_PROTO)
    sim_real = cosine(e, REAL_PROTO)
    exp_f    = math.exp(sim_fake * 5)
    exp_r    = math.exp(sim_real * 5)
    return exp_f / (exp_f + exp_r)

# ── VeriScore Engine ─────────────────────────────────────────
def compute_veriscore(text, speaker='unknown'):
    lf       = extract_linguistic_features(text)
    spk_cred = SPEAKER_MEMORY.get(str(speaker).lower().strip(), {}).get('cred_score', 0.5)
    feat     = np.array([[lf[c] for c in LING_COLS] + [spk_cred]])
    feat_sc  = scaler.transform(feat.astype(float))
    xgb_fake = float(xgb_model.predict_proba(feat_sc)[0][0])
    bert_fake = bert_fake_probability(text)
    spk_fake  = 1 - spk_cred
    wfake     = 0.40*bert_fake + 0.35*xgb_fake + 0.25*spk_fake
    score     = round((1 - wfake) * 100, 1)
    if   score >= 90: verdict, color, bg = "✅ Highly Trustworthy", "#437a22", "#edf7e8"
    elif score >= 70: verdict, color, bg = "🟡 Mostly Reliable",    "#d19900", "#fdf8e1"
    elif score >= 50: verdict, color, bg = "🟠 Needs Verification", "#da7101", "#fff3e0"
    elif score >= 30: verdict, color, bg = "🔴 Suspicious",         "#a13544", "#fde8ea"
    else:             verdict, color, bg = "❌ Likely Fake",         "#a12c7b", "#fce8f4"
    sv        = explainer.shap_values(feat_sc)[0]
    top_idx   = np.argsort(np.abs(sv))[::-1][:5]
    top_feats = [(FEAT_COLS[i], round(float(sv[i]),4)) for i in top_idx]
    reasons   = []
    if lf['emo_ratio']       > 0.03: reasons.append("High emotional language")
    if lf['clickbait_score'] > 0.05: reasons.append("Clickbait indicators")
    if lf['caps_ratio']      > 0.08: reasons.append("Unusual capitalization")
    if lf['excl_density']    > 0.50: reasons.append("Excessive exclamation marks")
    if lf['certainty_ratio'] > 0.03: reasons.append("Overconfident language")
    if lf['neg_framing']     > 0.03: reasons.append("Negative framing")
    if lf['hedge_ratio']     > 0.04: reasons.append("Hedging language")
    if spk_cred              < 0.40: reasons.append(f"Low speaker credibility ({round(spk_cred,2)})")
    if not reasons:                  reasons.append("No strong deception signals")
    return {'score': score, 'verdict': verdict, 'color': color, 'bg': bg,
            'bert_pct': round(bert_fake*100,1), 'xgb_pct': round(xgb_fake*100,1),
            'spk_cred': round(spk_cred*100,1), 'top_features': top_feats,
            'reasons': reasons,
            'recommend': "Verify using BBC, Reuters or Snopes before sharing."
                         if score < 60 else "Appears credible. Standard verification recommended."}

# ── Sidebar ──────────────────────────────────────────────────
with st.sidebar:
    st.markdown("""
    <div style='padding:6px 0 18px'>
        <div style='font-size:2.5rem;line-height:1'>🔍</div>
        <div style='font-family:Fraunces,serif;font-size:1.55rem;font-weight:800;margin-top:10px'>MultiVerify</div>
        <div style='color:rgba(255,255,255,0.76);font-size:0.85rem;margin-top:4px'>Explainable information verification</div>
        <div style='margin-top:14px;padding:12px 14px;border-radius:18px;background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.08)'>
            <div style='font-weight:700;font-size:0.86rem'>Live model status</div>
            <div style='font-size:0.82rem;color:rgba(255,255,255,0.72);margin-top:4px'>XGBoost + DistilBERT + SHAP</div>
        </div>
    </div>
    """, unsafe_allow_html=True)
    st.markdown("### VeriScore™ Guide")
    for rng, lbl, c in [("90–100","✅ Highly Trustworthy","#437a22"),
                         ("70–89", "🟡 Mostly Reliable",  "#d19900"),
                         ("50–69", "🟠 Needs Verification","#da7101"),
                         ("30–49", "🔴 Suspicious",        "#a13544"),
                         ("0–29",  "❌ Likely Fake",        "#a12c7b")]:
        st.markdown(f"<span style='color:{c};font-weight:600'>{lbl}</span>"
                    f"<br><span style='font-size:0.8rem;color:#7a7974'>{rng}/100</span>",
                    unsafe_allow_html=True)
    st.markdown("---")
    st.success(f"XGBoost model loaded")
    st.success(f"DistilBERT on {DEVICE}")
    st.info(f"Speaker profiles: {len(SPEAKER_MEMORY)}")
    st.caption("Tip: paste a claim, then inspect both the trust score and the explanation chips.")

# ── Main UI ──────────────────────────────────────────────────
st.markdown("""
<div class='hero'>
    <h1>Trust scoring with receipts.</h1>
    <p>MultiVerify blends linguistic signals, speaker credibility, and semantic model outputs into a single VeriScore, then explains why the score moved the way it did.</p>
    <div class='pill-row'>
        <div class='pill'>⚡ Real-time analysis</div>
        <div class='pill'>🧠 SHAP explanations</div>
        <div class='pill'>📰 Article and claim verification</div>
        <div class='pill'>🔒 Speaker memory support</div>
    </div>
</div>
""", unsafe_allow_html=True)
st.markdown("<div style='height:18px'></div>", unsafe_allow_html=True)

tab1, tab2, tab3 = st.tabs(["🔎 Verify Article", "📊 Model Analytics", "ℹ️ About"])

# ── TAB 1 ────────────────────────────────────────────────────
with tab1:
    col1, col2 = st.columns([1.1, 0.9], gap="large")
    with col1:
        st.markdown("<div class='panel'>", unsafe_allow_html=True)
        st.markdown("<div style='color:var(--ink);font-size:1.05rem;font-weight:800;margin-bottom:6px'>Paste Article or Claim</div>", unsafe_allow_html=True)
        st.caption("Drop in a headline, claim, or paragraph. The app will score it and explain the top signals.")
        text_input = st.text_area("", placeholder="Paste any news headline or article here...", height=200)
        st.markdown("<div style='color:var(--ink);font-size:0.95rem;font-weight:700;margin:12px 0 6px'>Speaker / Source (optional)</div>", unsafe_allow_html=True)
        speaker    = st.text_input("", value="unknown",
                                   placeholder="e.g. barack-obama, donald-trump")
        st.markdown("<div class='examples-box'>", unsafe_allow_html=True)
        st.markdown("<div class='examples-title'>💡 Try example claims</div>", unsafe_allow_html=True)
        examples = [
            "Scientists confirm vaccine 95% effective in peer-reviewed clinical trials",
            "SHOCKING: Government secretly poisons water — they don't want you to know!!!",
            "Federal Reserve raises interest rates by 0.25 basis points this quarter",
        ]
        for index, ex in enumerate(examples):
            if st.button(ex[:65] + "...", key=f"example_{index}"):
                text_input = ex
        st.markdown("</div>", unsafe_allow_html=True)
        run = st.button("🔍 Verify Now", use_container_width=True)
        st.markdown("</div>", unsafe_allow_html=True)

    with col2:
        if run and text_input.strip():
            with st.spinner("Analyzing with MultiVerify..."):
                r = compute_veriscore(text_input, speaker)
                st.markdown(f"""
                <div class='score-box' style='background:linear-gradient(180deg, {r["bg"]} 0%, rgba(255,255,255,0.96) 100%);border-color:{r["color"]}'>
                    <div style='color:{r["color"]};font-size:0.86rem;font-weight:800;letter-spacing:0.08em;text-transform:uppercase'>VeriScore™</div>
                    <div class='big-score' style='color:{r["color"]};font-family:Fraunces,serif'>{r["score"]}</div>
                    <div style='font-size:0.82rem;color:var(--muted);margin-top:4px'>out of 100</div>
                    <div class='verdict' style='color:{r["color"]}'>{r["verdict"]}</div>
                </div>
                """, unsafe_allow_html=True)
            st.markdown("<br>", unsafe_allow_html=True)
            metric_cols = st.columns(3)
            metric_payload = [
                ("BERT Fake %", f"{r['bert_pct']}%", "Semantic probability"),
                ("XGB Fake %", f"{r['xgb_pct']}%", "Style + structure"),
                ("Speaker Cred", f"{r['spk_cred']}%", "Historical reputation"),
            ]
            for col, (label, value, note) in zip(metric_cols, metric_payload):
                with col:
                    st.markdown(f"""
                    <div class='metric-card'>
                        <div class='metric-label'>{label}</div>
                        <div class='metric-value'>{value}</div>
                        <div class='metric-note'>{note}</div>
                    </div>
                    """, unsafe_allow_html=True)

            st.markdown("<div style='height:10px'></div>", unsafe_allow_html=True)
            st.markdown("<div class='panel'>", unsafe_allow_html=True)
            st.markdown("**⚠️ Key Signals**")
            chips = "".join([f'<span class="chip">{x}</span>' for x in r['reasons']])
            st.markdown(chips, unsafe_allow_html=True)
            st.markdown("**🧠 Top SHAP Features**")
            fn  = [x[0] for x in r['top_features']]
            fv  = [x[1] for x in r['top_features']]
            clr = ["#a12c7b" if v < 0 else "#01696f" for v in fv]
            fig = go.Figure(go.Bar(x=fv, y=fn, orientation='h',
                                   marker_color=clr,
                                   text=[f"{v:+.4f}" for v in fv],
                                   textposition='outside'))
            fig.update_layout(height=230, margin=dict(l=0,r=40,t=5,b=5),
                              yaxis=dict(autorange='reversed'),
                              plot_bgcolor='white', paper_bgcolor='white',
                              font=dict(size=11))
            st.plotly_chart(fig, use_container_width=True)
            st.info(f"💡 {r['recommend']}")
            st.markdown("</div>", unsafe_allow_html=True)
        elif run:
            st.warning("Please paste a claim or article first.")
        else:
            st.markdown("""
            <div class='panel' style='min-height:420px;display:flex;align-items:center;justify-content:center;text-align:center'>
                <div>
                    <div style='font-size:3rem;line-height:1;color:var(--ink)'>📰</div>
                    <div style='font-family:Fraunces,serif;font-size:1.45rem;font-weight:800;margin-top:14px;color:var(--ink)'>Start with a headline or claim</div>
                    <div style='max-width:340px;margin:10px auto 0;color:var(--muted)'>Paste text on the left, press verify, and review the score, metrics, and SHAP signals here.</div>
                </div>
            </div>
            """,
                        unsafe_allow_html=True)

# ── TAB 2 ────────────────────────────────────────────────────
with tab2:
    st.markdown("<div class='panel'>", unsafe_allow_html=True)
    st.markdown("#### Model Performance")
    st.caption("Snapshot metrics and artifacts bundled with the package.")
    import os
    c1,c2,c3,c4 = st.columns(4)
    try:
        with open('multiverify_metrics.json') as f:
            m = json.load(f)
        metrics = [
            (c1, "Accuracy", f"{m['accuracy']:.2%}"),
            (c2, "F1 Score", str(m['f1_score'])),
            (c3, "ROC-AUC", str(m['roc_auc'])),
            (c4, "Speakers", str(m['speakers'])),
        ]
    except:
        metrics = [
            (c1, "Accuracy", "~67%"),
            (c2, "F1 Score", "~0.67"),
            (c3, "ROC-AUC", "~0.74"),
            (c4, "Speakers", str(len(SPEAKER_MEMORY))),
        ]

    for col, label, value in metrics:
        with col:
            st.markdown(f"""
            <div class='metric-card'>
              <div class='metric-label'>{label}</div>
              <div class='metric-value'>{value}</div>
              <div class='metric-note'>bundled model snapshot</div>
            </div>
            """, unsafe_allow_html=True)

    col_a, col_b = st.columns(2)
    with col_a:
        if os.path.exists('shap_bar.png'):
            st.image('shap_bar.png', caption='SHAP Feature Importance', use_container_width=True)
    with col_b:
        if os.path.exists('eval_plots.png'):
            st.image('eval_plots.png', caption='Confusion Matrix + ROC Curve', use_container_width=True)

    st.markdown("#### Architecture")
    st.dataframe(pd.DataFrame({
        'Module':    ['DistilBERT','XGBoost','Speaker Memory','VeriScore™ Fusion'],
        'Input':     ['Raw text','26 ling. features + cred_score','Speaker name','3 model outputs'],
        'Output':    ['Fake probability','Fake probability','Credibility score','Trust score 0–100'],
        'Weight':    ['40%','35%','25%','—'],
    }), hide_index=True, use_container_width=True)
    st.markdown("</div>", unsafe_allow_html=True)

# ── TAB 3 ────────────────────────────────────────────────────
with tab3:
    st.markdown("<div class='panel'>", unsafe_allow_html=True)
    st.markdown("""
    ## MultiVerify — Explainable AI for Trustworthy Information Verification
    **IEEE DataPort Hackathon 2026**

    ### Innovation: VeriScore™
    Instead of binary Fake/Real labels, MultiVerify outputs a **0–100 Trust Score** with:
    - Human-readable signal explanations
    - SHAP feature attribution
    - Speaker credibility history (3000+ profiles from LIAR)
    - Actionable recommendations

    ### Datasets
    | Dataset | Purpose |
    |---------|---------|
    | LIAR (12K claims) | XGBoost training + speaker memory |
    | FakeNewsNet (PolitiFact + BuzzFeed) | Extended article training |
    | DistilBERT | Zero-shot semantic scoring |

    ### Tech Stack
    Python · PyTorch · HuggingFace · XGBoost · SHAP · Streamlit · Plotly
    """)
    st.markdown("</div>", unsafe_allow_html=True)